/*Angelo LaGreca
 Worked alone
 Everything complete except the background music seems to be having a problem. all the sound FX are working proper, just not the background music.
 Ive tried a couple things to fix this, and im sure it is simple enough, but ive broken and fixed this program so many times I'm not chancing it again.
 Some of the Challenges were pretty difficult, but I think i learned more from this than i did from most of the text chapters. In my opinion, this text
 did a bit of a better job explaining the pieces we added to the program. Not to say the other text book didnt explain things, but at times i found the language
 to be so technical it was a bit difficult to understand. To be fair, this could be because of how tired i usually am at night. But the zombie conga text
 was simple but informative. Easier to follow.
*/



import UIKit
import SpriteKit


class GameViewController: UIViewController
{
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        //this is where we need to change the starting screen to the main menu screen instead of the defalt game screen
       // let scene =
           // GameScene(size:CGSize(width: 2048, height: 1536))
        
        let scene = MainMenuScene(size: CGSize(width: 2000, height: 1600))
        
        
        let skView = self.view as! SKView
        skView.showsFPS = true
        skView.showsNodeCount = true
        skView.ignoresSiblingOrder = true
        scene.scaleMode = .aspectFill
        skView.presentScene(scene)
    }
    override var prefersStatusBarHidden: Bool
    {
        return true
    }
}
